package com.efulltech.etpspay.utils;



public final class Constants {
    public static final String PREFS = "Prefs";
    private static final String PACKAGE_NAME = "com.sanxynet.efullnew";
    public static final String ADMIN_PIN = "admin_pin";
    public static final String SUPERVISOR_PIN = "supervisor_pin";
    public static final String OPERATOR_PIN = "operator_pin";
    public static final String PERMISSION = "permission";
    public static final String ADMIN = "admin";
    public static final String SUPERVISOR = "supervisor";
    public static final String OPERATOR = "operator";



}
